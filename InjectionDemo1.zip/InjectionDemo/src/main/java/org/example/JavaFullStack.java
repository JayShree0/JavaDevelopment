package org.example;

public class JavaFullStack implements Course{

    @Override
    public int enroll() {
        return 1;
    }
}
