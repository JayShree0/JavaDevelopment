package org.example;

public class DSA implements Course{

    @Override
    public int enroll() {
        return 1;
    }
}
