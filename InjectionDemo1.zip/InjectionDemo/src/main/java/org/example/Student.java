package org.example;

public class Student {

//    “Declare a private reference variable named course that can hold the address of a Course object.”
    private Course course; // course type ka object


    // course was null, so null.enroll() caused error.
    public void study() {
        int start = course.enroll();
        System.out.println(start);
        if(start >= 1){
            System.out.println("Journey started....");
        } else{
            System.out.println("Payment Failed...");
        }
    }
}
